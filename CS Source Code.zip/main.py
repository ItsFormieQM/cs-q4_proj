from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, timedelta
import random

# simple flask application. users can register, login, earn points, buy items, and play mini-games
# cooldown for the daily claim (0.15 minutes = 9 seconds)
COOLDOWN_MINUTES = 0.15 

app = Flask(__name__)
app.secret_key = "maul" # encryption key for session security

# in-memory database of users, keys are usernames and values hold password, points, and inventory
users = {
    "admin": {"password": "255", "points": 99999999, "inventory": []},
    "ItsFormieQM": {"password": "chara", "points": 5000, "inventory": []}
}

shop_items = {
    "potion": { # internal item id 
        "name": "Health Potion", # display name
        "price": 10, # price in points
        "frames": ["heal.png", "heal.png"], # list of images for animations
        "anim_speed": 1, # how much delay to load between frames
        "text_color": "none" # text shader and image shader, deprecated but cant bother to remove it
    },
    "tricky_tony": {
        "name": "Annoying Dog", 
        "price": 500, 
        "frames": ["DOG_1.png", "DOG_2.png"], 
        "anim_speed": 0.4, 
        "text_color": "none"
    },
    "save_lw": {
        "name": "SAVE ORB", 
        "price": 1000, 
        "frames": ["save_1.png", "save_2.png"], 
        "anim_speed": 0.5, 
        "text_color": "none"
    },
    "determination": {
        "name": "DETERMINATION", 
        "price": 9999, 
        "frames": ["soul.png", "soul.png"], 
        "anim_speed": 1, 
        "text_color": "none"
    },
    "patience": {
        "name": "PATIENCE", 
        "price": 9999, 
        "frames": ["soul_cyan.png", "soul_cyan.png"], 
        "anim_speed": 1, 
        "text_color": "none"
    },
}

@app.route("/") # main
# show the dashboard/home card if the user is logged in, otherwise redirect to login
def home():
    if "user" in session:
        username = session["user"]
        user_data = users.get(username)
        
        if not user_data: 
            session.pop("user", None)
            return redirect(url_for("login"))

        return render_template("home.html", username=username, user=user_data, shop_items=shop_items)

    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
# handle login form display and submission
def login():
    if request.method == "POST": 
        username = request.form.get("username")
        password = request.form.get("password")

        if username in users:
            if users[username]["password"] == password:
                session["user"] = username
                return redirect(url_for("home"))
            else:
                flash("Invalid password.") 
        else:
            flash("User not found.") 
            
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
# registration page where new accounts are created
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            flash("Please fill in all fields.")
        elif username in users:
            flash("Username already exists!")
        else:
            users[username] = {
                "password": password,
                "points": 50,
                "inventory": []
            }
            flash("Account created! You can now sign in.")
            return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/shop")
# show list of shop items and current user points
def shop():
    if "user" not in session:
        flash("Please log in to view the shop.") 
        return redirect(url_for("login"))

    username = session["user"]
    user_data = users.get(username)

    return render_template(
        "shop.html", 
        shop_items=shop_items, 
        user_points=user_data["points"]
    )

@app.route("/buy/<item_id>", methods=["POST"])
# process purchase request for item_id, deduct points and add to inventory
def buy_item(item_id):
    if "user" not in session:
        return redirect(url_for("login"))

    username = session["user"]
    user_data = users.get(username)
    item = shop_items.get(item_id)

    if item is None:
        flash("Item not found.")
        return redirect(url_for("shop"))

    if user_data["points"] >= item["price"]:
        user_data["points"] -= item["price"]
        user_data["inventory"].append(item_id) 
        flash(f"Successfully bought {item['name']}!")
    else:
        flash("Not enough points!")

    return redirect(url_for("shop"))

@app.route("/claim-daily", methods=["POST"])
# give user a daily bonus if cooldown has expired
def claim_daily():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    username = session["user"]
    user_entry = users[username]

    can_claim, seconds_left = check_cooldown(user_entry, COOLDOWN_MINUTES)

    if not can_claim:
        flash(f"Claim failed! Try again in {seconds_left} seconds.", "error") 
    else:
        user_entry["points"] += 10 
        user_entry["last_claim_time"] = datetime.now()
        flash("Daily bonus claimed! +10 points.", "success")

    return redirect(url_for("home"))

def check_cooldown(user_data, COOLDOWN_MINUTES):
    # helper that returns (can_claim, seconds_remaining) based on last_claim_time

    now = datetime.now()
    last_claim = user_data.get("last_claim_time")

    if last_claim:
        allowed_time = last_claim + timedelta(minutes=COOLDOWN_MINUTES)
        if now <= allowed_time:
            remaining = int((allowed_time - now).total_seconds())
            return False, remaining

    return True, -1

@app.route("/admin-dashboard")
# admin-only page listing all users and controls
def admin_dashboard():
    if session.get("user") == "admin":
        return render_template("admin_dashboard.html", users_dict=users)

    flash("Unauthorized access!")
    return redirect(url_for("home"))

@app.route("/delete-user/<username>", methods=["POST"])
# allow admin to remove a non-admin user from the system
def delete_user(username):
    if session.get("user") == "admin" and username != "admin":
        users.pop(username, None) 
        flash(f"User {username} deleted.")
    return redirect(url_for('admin_dashboard'))

@app.route("/edit-user/<username>", methods=["GET", "POST"])
# admin interface to change a user's password or points
def edit_user(username):
    if session.get("user") != "admin":
        flash("Only Admins can access this!")
        return redirect(url_for("home"))

    if username not in users:
        flash("User not found.")
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        new_password = request.form.get("password")
        new_points = request.form.get("points")
        users[username]["password"] = new_password
        try:
            users[username]["points"] = int(new_points)
            flash(f"Updated {username} successfully.")
        except ValueError:
            flash("Invalid points value.")
        return redirect(url_for("admin_dashboard"))

    return render_template("edit_user.html", username=username, user_data=users[username])

@app.route("/logout")
# clear the session to sign the user out
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

@app.route("/games")
# games page where user can solve math problems to earn points
def games_page():
    if "user" not in session: # security check
        return redirect(url_for("login"))
    
    username = session["user"]
    user_data = users.get(username)
    
    # pass everthing
    return render_template("games.html", username=username, user=user_data, shop_items=shop_items)

@app.route("/generate-math")
def generate_math():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    # define operations and pick one
    operators = ["+", "-", "*", "/"]
    operator = random.choice(operators)
    
    # generate numbers based on the operator
    if operator == '+':
        num1 = random.randint(-666, 666)
        num2 = random.randint(-666, 666)
        answer = num1 + num2
        symbol = "+"
    elif operator == '-':
        num1 = random.randint(-666, 666)
        num2 = random.randint(-666, 666)
        answer = num1 - num2
        symbol = "-"
    elif operator == "*":
        num1 = random.randint(-66, 66)
        num2 = random.randint(-66, 66)
        answer = num1 * num2
        symbol = "*"
    else: # division
        answer = random.randint(-10, 5000)
        num2 = random.randint(-10, 5000)
        num1 = answer * num2 # guaranteed whole number
        symbol = "÷"

    # store in session
    session["math_answer"] = answer
    session["math_equation"] = f"{num1} {symbol} {num2}"
    session["math_solved"] = False 

    return redirect(url_for("games_page"))

@app.route("/verify-math", methods=["POST"])
# check the user's guess against the stored math problem, award points if correct
def verify_math():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    if "math_answer" not in session:
        flash("No active math challenge! Click 'Get Task first.'", "error")
        return redirect(url_for("home"))

    user_guess = request.form.get("guess")
    correct_answer = session.get("math_answer")
    points_gained = 0
    points_lost = 0
    user_points = 0

    if not user_guess:
        flash("You didn't enter anything!", "error")
        return redirect(url_for("games_page"))

    if int(user_guess) == correct_answer:
        username = session["user"]
        points_gained = random.randint(5, 500)
        users[username]["points"] += points_gained
        flash(f"Correct! {points_gained} points gained!", "success")
        session.pop("math_answer", None)
        session.pop("math_equation", None)
    else:
        username = session["user"]
        points_lost = random.randint(1, 250)
        if users[username]["points"] >= points_lost:
            users[username]["points"] -= points_lost
            if points_lost != 1:
                flash(f"Incorrect! You lost {points_lost} points.", "error")
            else:
                flash(f"Incorrect! You lost {points_lost} point.", "error")
        else:
            flash(f"Incorrect! Please try again!", "error")

    return redirect(url_for("games_page"))

@app.route("/settings", methods=["GET", "POST"])
# allow users to update their username or password (with current password check)
def settings():
    if "user" not in session:
        return redirect(url_for("login"))

    old_username = session["user"]
    user_data = users.get(old_username)

    if request.method == "POST":
        current_password = request.form.get("current_password")
        new_username = request.form.get("username").strip()
        new_password = request.form.get("password")

        # verify old password
        if current_password != user_data.get("password"):
            flash("Incorrect current password. Changes not saved.", "error")
            return redirect(url_for("settings"))

        # proceed update if password is correct
        if new_username != old_username:
            if new_username in users:
                flash("Username already taken.", "error")
                return redirect(url_for("settings"))
            
            # transfer data to new key
            users[new_username] = users.pop(old_username)
            session["user"] = new_username
            user_data = users[new_username]

        user_data["password"] = new_password
        flash("Profile updated successfully!", "success")
        return redirect(url_for("home"))

    return render_template("settings.html", user=user_data, username=old_username)


@app.route("/delete-account", methods=["POST"])
# let a logged-in user delete their own account after confirming password
def delete_account():
    if "user" not in session:
        return redirect(url_for("login"))

    username = session["user"]
    password_attempt = request.form.get("delete_password")
    user_data = users.get(username)

    # verify for security
    if user_data and user_data.get("password") == password_attempt:
        users.pop(username)
        session.clear()
        flash("Account was deleted.", "info")
        return redirect(url_for("login"))
    else:
        flash("Incorrect password! Action cancelled.", "error")
        return redirect(url_for("settings"))

if __name__ == "__main__":
    app.run(debug=True)