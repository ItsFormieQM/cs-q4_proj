from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, timedelta
import random

# Cooldown for the daily claim (0.15 minutes = 9 seconds)
COOLDOWN_MINUTES = 0.15 

app = Flask(__name__)
app.secret_key = "maul" # Encryption key for session security

# In-memory database
users = {
    "admin": {"password": "255", "points": 99999999, "inventory": []},
    "ItsFormieQM": {"password": "chara", "points": 5000, "inventory": []}
}

shop_items = {
    "potion": {
        "name": "Health Potion", 
        "price": 10, 
        "frames": ["heal.png", "heal.png"], 
        "anim_speed": 1, 
        "text_color": "none"
    },
    "tricky_tony": {
        "name": "Annoying Dog", 
        "price": 500, 
        "frames": ["DOG_1.png", "DOG_2.png"], 
        "anim_speed": 0.4, 
        "text_color": "none"
    },
    "save_lw": {
        "name": "SAVE ORB", 
        "price": 1000, 
        "frames": ["save_1.png", "save_2.png"], 
        "anim_speed": 0.5, 
        "text_color": "none"
    },
    "determination": {
        "name": "DETERMINATION", 
        "price": 9999, 
        "frames": ["soul.png", "soul.png"], 
        "anim_speed": 1, 
        "text_color": "#ff0000"
    }
}

# --- ROUTES ---

@app.route("/")
def home():
    if "user" in session:
        username = session["user"]
        user_data = users.get(username)
        
        if not user_data:
            session.pop("user", None)
            return redirect(url_for("login"))

        return render_template("home.html", username=username, user=user_data, shop_items=shop_items)

    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST": 
        username = request.form.get("username")
        password = request.form.get("password")

        if username in users:
            if users[username]["password"] == password:
                session["user"] = username
                return redirect(url_for("home"))
            else:
                flash("Invalid password.") 
        else:
            flash("User not found.") 
            
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            flash("Please fill in all fields.")
        elif username in users:
            flash("Username already exists!")
        else:
            users[username] = {
                "password": password,
                "points": 50,
                "inventory": []
            }
            flash("Account created! You can now sign in.")
            return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/shop")
def shop():
    if "user" not in session:
        flash("Please log in to view the shop.") 
        return redirect(url_for("login"))

    username = session["user"]
    user_data = users.get(username)

    return render_template(
        "shop.html", 
        shop_items=shop_items, 
        user_points=user_data["points"]
    )

@app.route("/buy/<item_id>", methods=["POST"])
def buy_item(item_id):
    if "user" not in session:
        return redirect(url_for("login"))

    username = session["user"]
    user_data = users.get(username)
    item = shop_items.get(item_id)

    if item is None:
        flash("Item not found.")
        return redirect(url_for("shop"))

    if user_data["points"] >= item["price"]:
        user_data["points"] -= item["price"]
        user_data["inventory"].append(item_id) 
        flash(f"Successfully bought {item['name']}!")
    else:
        flash("Not enough points!")

    return redirect(url_for("shop"))

@app.route("/claim-daily", methods=["POST"])
def claim_daily():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    username = session["user"]
    user_entry = users[username]

    can_claim, seconds_left = check_cooldown(user_entry, COOLDOWN_MINUTES)

    if not can_claim:
        flash(f"Claim failed! Try again in {seconds_left} seconds.", "error") 
    else:
        user_entry["points"] += 10 
        user_entry["last_claim_time"] = datetime.now()
        flash("Daily bonus claimed! +10 points.", "success")

    return redirect(url_for("home"))

def check_cooldown(user_data, COOLDOWN_MINUTES):
    now = datetime.now()
    last_claim = user_data.get("last_claim_time")

    if last_claim:
        allowed_time = last_claim + timedelta(minutes=COOLDOWN_MINUTES)
        if now < allowed_time:
            remaining = int((allowed_time - now).total_seconds())
            return False, remaining

    return True, 0

@app.route("/admin-dashboard")
def admin_dashboard():
    if session.get("user") == "admin":
        return render_template("admin_dashboard.html", users_dict=users)

    flash("Unauthorized access!")
    return redirect(url_for("home"))

@app.route("/delete-user/<username>", methods=["POST"])
def delete_user(username):
    if session.get("user") == "admin" and username != "admin":
        users.pop(username, None) 
        flash(f"User {username} deleted.")
    return redirect(url_for('admin_dashboard'))

@app.route("/edit-user/<username>", methods=["GET", "POST"])
def edit_user(username):
    if session.get("user") != "admin":
        flash("Only Admins can access this!")
        return redirect(url_for("home"))

    if username not in users:
        flash("User not found.")
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        new_password = request.form.get("password")
        new_points = request.form.get("points")
        users[username]["password"] = new_password
        try:
            users[username]["points"] = int(new_points)
            flash(f"Updated {username} successfully.")
        except ValueError:
            flash("Invalid points value.")
        return redirect(url_for("admin_dashboard"))

    return render_template("edit_user.html", username=username, user_data=users[username])

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

@app.route("/games")
def games_page():
    if "user" not in session: # security check
        return redirect(url_for("login"))
    
    username = session["user"]
    user_data = users.get(username)
    
    # pass everthing
    return render_template("games.html", username=username, user=user_data, shop_items=shop_items)

@app.route("/generate-math")
def generate_math():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))
    
    num1 = random.randint(1, 20)
    num2 = random.randint(1, 20)
    
    session["math_answer"] = num1 + num2
    session["math_equation"] = f"{num1} + {num2}"
    
    return redirect(url_for("games_page"))

@app.route("/verify-math", methods=["POST"])
def verify_math():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    if "math_answer" not in session:
        flash("No active math challenge! Click 'Get Task first.'", "error")
        return redirect(url_for("home"))

    user_guess = request.form.get("guess")
    correct_answer = session.get("math_answer")

    try:
        if not user_guess:
            flash("You didn't enter anything!", "error")
            return redirect(url_for("games_page"))

        if int(user_guess) == correct_answer:
            username = session["user"]
            users[username]["points"] += 5
            flash("Correct! +5 Points.", "success")
            session.pop("math_answer", None)
            session.pop("math_equation", None)
        else:
            flash(f"Incorrect! The answer wasn't {user_guess}.", "error")
            
    except(ValueError, TypeError):
        flash("Please input numbers only!", "error") 

    return redirect(url_for("games_page"))

@app.route("/settings", methods=["GET", "POST"])
def settings():
    if "user" not in session:
        return redirect(url_for("login"))

    old_username = session["user"]
    user_data = users.get(old_username)

    if request.method == "POST":
        new_username = request.form.get("username").strip()
        new_password = request.form.get("password")

        # check
        if not new_username or not new_password:
            flash("Fields cannot be empty!", "error")
            return redirect(url_for("settings"))

        # check if the new username is already taken by someone else
        if new_username != old_username and new_username in users:
            flash("That username is already taken!", "error")
            return redirect(url_for("settings"))

        # handle the changing
        if new_username != old_username:
            # create new key with existing data
            users[new_username] = users.pop(old_username)
            # update the session so the user stays logged in 
            session["user"] = new_username
            # update data
            user_data = users[new_username]

        # update password
        user_data["password"] = new_password
        
        flash("Profile updated successfully!", "success")
        return redirect(url_for("home"))

    return render_template("settings.html", user=user_data, username=old_username)

if __name__ == "__main__":
    app.run(debug=True)